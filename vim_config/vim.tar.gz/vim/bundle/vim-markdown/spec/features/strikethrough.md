~~one line strikethrough~~

~~multiple line
strike through~~

The end could not be escaped ~~this is striked\~~

There is no escape in the middle ~~this is \~~ striked~~ so the end is not striked

The begin could be escaped \~~this is not striked~~

* this is a list ~~with a strikethrough~~

# this is a header ~~with a strikethrough~~ this is still part of the header

~~strikethrough *could* __contain__ other http://google.it inline elements~~

~~
could not begin
with a new line
this is not striked~~

~~ could not begin with a space this is not striked~~

~~could not end with a space, this is not striked ~~

~~could not end
with a newline
this is not striked
~~
