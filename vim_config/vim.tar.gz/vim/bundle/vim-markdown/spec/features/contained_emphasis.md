
# This is an header that _contains_ *weak* highlighed elements

# This is an header that __contains__ **strong** highlighed elements

## This is an header that __*contains*__ **_strong_** emphasis elements

This is also an header that _contains_ *weak* highlighed elements
=================================================================

This is an header that __contains__ **strong** highlighed elements
------------------------------------------------------------------
