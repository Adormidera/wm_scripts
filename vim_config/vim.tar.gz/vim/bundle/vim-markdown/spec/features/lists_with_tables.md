* First level, first item with table

  Header-1|Header-2
  ---|---
  Row-1-Column-1|Row-1-Column-2

  * Second level, first item with table

      Header-1|Header-2
      ---|---
      Row-1-Column-1|Row-1-Column-2
      Row-2-Column-1|Row-2-Column-2
      Row-3-Column-1|Row-3-Column-2
      Row-4-Column-1|Row-4-Column-2

  * Second level, second item with table, it's not a code block, tables could have as many leading spaces as wanted

                      Header-1|Header-2
                      ---|---
                      Row-1-Column-1|Row-1-Column-2
                      Row-2-Column-1|Row-2-Column-2
                      Row-3-Column-1|Row-3-Column-2
                      Row-4-Column-1|Row-4-Column-2

    * Third level, first item
      * Fourth level, first item
        * Fifth level, first item

      The following it's a table in the third level list item

      Header-1|Header-2
      ---|---
      Row-1-Column-1|Row-1-Column-2

      Header-1|Header-2
      ---|---
