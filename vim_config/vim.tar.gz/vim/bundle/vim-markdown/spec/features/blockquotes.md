> This is a blockquote

 > This is a blockquote even if the angle bracket is not at the beginning of the line

> This is a single
> blockquote even if it
> spans a few lines

> This is a single
blockquote, you can put the angle bracket
jnly at the first line of the paragraph and
the all the paragraph is a blockquote

This is not a blockquote because it's another paragraph

>
This is not a blockquote because the first line, the line with the angle bracket, must not be empty

> 
This is a blockquote because the first line, the line with the angle bracket, is not empty, in this case contains a single space

And again, this is not a blockquote because is another paragraph
