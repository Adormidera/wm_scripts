Hello        {#id-1}
-----

Hello        {#id-2}
=====

# Header With Identifier {#id-3}

# Header With Trailing Hashes and Identifier # {#id-4}

# Trailing Hashes could be as many as you want ####### {#id-5}

# Header With Hashes # In Text and Identifier {#id-6}

The following should a level 1 header with a `#` character for content

##

The following should a level 2 header with a `#` character for content

###
