# One

## Two

### Three

#### Four

##### Five

###### Six

# One with closing hash #

## Two with closing hash #

### Three with closing hash #

#### Four with closing hash #

##### Five with closing hash #

###### Six with closing hash #

# Can have multiple closing hashes #####

# An hash in the middle # have no special meaning

 # This should not be an header because the hash should be the first character in the line

This is # not an header, this is a normal paragraph and the hash must not be considered a delimiter

####### Seven hashes is an `H6` that begins with an hash character for Dingus but for Github those are seven hashes, an header must have a mandatory space before any character

######This is not an header on Github because it lacks the mandatory white space between the hashes (delimiter) and the first character of the header
