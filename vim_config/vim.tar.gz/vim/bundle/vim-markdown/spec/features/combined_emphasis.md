
___foo___ must be both highlighted as italic and bold

***foo*** must be both highlighted as italic and bold

**_foo_** must be both highlighted as italic and bold

__*foo*__ must be both highlighted as italic and bold
